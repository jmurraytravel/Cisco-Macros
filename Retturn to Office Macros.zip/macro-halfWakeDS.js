const xapi = require('xapi');


function addActionPanel() {
  var paneldata = `
  <Extensions>
  <Version>1.7</Version>
  <Panel>
    <Order>3</Order>
    <PanelId>half_wake</PanelId>
    <Type>Home</Type>
    <Icon>Lightbulb</Icon>
    <Name>Half Wake</Name>
    <ActivityType>Custom</ActivityType>
    <Page>
      <Name>Force System to Half Wake</Name>
      <Row>
        <Name>Row</Name>
        <Widget>
          <WidgetId>half_wake</WidgetId>
          <Type>Button</Type>
          <Options>size=1;icon=power</Options>
        </Widget>
      </Row>
      <PageId>half_wake</PageId>
      <Options>hideRowNames=1</Options>
    </Page>
  </Panel>
</Extensions>
    `;
 xapi.command('UserInterface Extensions Panel Save', {PanelId:'halfWakeDS'}, paneldata)
}

addActionPanel();


xapi.event.on('UserInterface Extensions Page Action', (event) => {
if(event.Type == 'Opened' && event.PageId == 'half_wake'){
xapi.command("Standby Halfwake");
}
});
