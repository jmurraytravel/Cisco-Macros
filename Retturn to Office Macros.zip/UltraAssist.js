//Control ultrasound in a demo area. 295197 Version 0.91
const xapi = require('xapi'),
  muteOthersWidgetId = 'muteOthers',
  volumeWidgetId = 'proximityVolume',
  switchWidgetId = 'proximitySwitch',
  muteStatusWidgetId = 'muteUltrasoundStatus',
  httpMode = 'https'; //set to http and enable HTTP+HTTPS on the video device or set to https and allow insecure connections with the httpclient on the video device

//Which endpoints are we going to control? Note that the credentials should be a Base64 encode of username:password and you should include this endpoint in the list!
//IP : Base64 encode of username:password
//YWRtaW46 is a Base64 encode of 'admin:' without the quotes
let endpoints = { 
  '10.47.49.142' : 'YWRtaW46',
  '10.47.49.150' : 'YWRtaW46',
  '10.47.49.134' : 'YWRtaW46',
  '10.47.49.141' : 'YWRtaW46',
  '10.47.49.135' : 'YWRtaW46'
};

const numberOfEndpoints = Object.keys(endpoints).length;

//Default ultrasound volumes as of CE9.8
let defaultUVolumes = [
  ['DX70', 60],
  ['DX80', 70],
  ['SX10', 70],
  ['SX20', 60],
  ['SX80', 60],
  ['MX200 G2', 50],
  ['MX300 G2', 50],
  ['MX700', 66],
  ['MX700ST', 66],
  ['MX800', 66],
  ['MX800ST', 66],
  ['MX800D', 66],
  ['Room Kit Mini', 60],
  ['Room Kit', 70],
  ['Codec Plus', 60],
  ['Codec Pro', 60],
  ['Room 55', 64],
  ['Room 55D', 60],
  ['Room 70S', 70],
  ['Room 70D', 70],
  ['Room 70S G2', 60],
  ['Room 70D G2', 60],
  ['Board 55', 58],
  ['Board 55S', 90],
  ['Board 70', 60],
  ['Board 70S', 90],
  ['Board 85S', 90],
  ['Desk Pro', 70]
],
myIP,
myType,
myDefaultUVolume,
muteCounter = 0,
remoteIP,
newVolume,
storedUltrasoundVolume,
myDefaultOveride = 0; //Set this to the value of ultrasound volume for this endpoint if you would like to overide the system type defaults above

//Figure out which endpoint we are.
xapi.status.get('Network 1 IPv4 Address').then((address) => {
  myIP = address;
});

//Find what type of endpoint we are
xapi.status.get('SystemUnit ProductPlatform').then((productPlatform) => {
  myType = productPlatform;
  
  let found = defaultUVolumes.find(function(el) { 
    return !!~el.indexOf( myType );
  });
  
  //Check if the overide is set, otherwise set default to match system type
  if (myDefaultOveride > 0) {
    myDefaultUVolume = myDefaultOveride;
  } else {
    if (typeof found !== 'undefined') {
      //Overide this with a static value if needed
      myDefaultUVolume = found[1];
    } else {
      //Safe default for unknown endpoints
      myDefaultUVolume = 60;
    }
  }
});

function parse(event) {
  return JSON.parse(event);
}

//Change widget text
function updateMessage(text) {
  xapi.command('UserInterface Extensions Widget SetValue', {
    Value: text,
    WidgetId: muteStatusWidgetId
  });
}

function updateSlider(value1, value2) {
  newVolume = Math.ceil(255 * value1 / value2);
  xapi.command('UserInterface Extensions Widget SetValue', {'Value': newVolume, 'WidgetId': volumeWidgetId});
}

//Transmitter
//-----------------------------

function postRequest(url, payload, auth) {
  xapi.command('HttpClient Post', { 
    Url: httpMode + '://' + url + '/putxml',
    AllowInsecureHTTPS: 'True',
    Header: ['Content-Type: text/xml', 'Authorization: Basic ' + auth]
  }, payload).then((response) => {
      if (response.StatusCode === '200') {
      console.log(url + ' mute requested');
      }
    });
  //console.log(payload);
}

function sendEvent(event, type) {
  event = event.replace(/"/g, "\'");
  var payload = '<XmlDoc internal="True"><Command><Message><Send><Text>'+ event +'</Text></Send></Message></Command></XmlDoc>';
  if (type === 'allOthers') {
    for (let [ip, credentials] of Object.entries(endpoints)) {
      if (ip !== myIP) {
        postRequest(ip, payload, credentials);
      }
    }
  } else if (type === 'response') {
    for (let [ip, credentials] of Object.entries(endpoints)) {
      if (ip === remoteIP) {
        console.log('Response sent to ' + ip);
        postRequest(ip, payload, credentials);
      }
    }
  }
}

//Receiver
//-----------------------------

function setConfig(config, value) {
  xapi.config.set(config, value).then(() => {
    muteCounter = 0;
    sendEvent(JSON.stringify({'response': {'Config' : config, 'Value' : value, 'Source' : myIP}}), 'response');
    updateMessage('This system is muted.');
    xapi.command('UserInterface Extensions Widget SetValue', {'Value': 'off', 'WidgetId': switchWidgetId});
    xapi.command('UserInterface Extensions Widget SetValue', {'Value': 0, 'WidgetId': volumeWidgetId});
  });
}

function statusText(source, volume) {
  if (volume === 0) {
    if (muteCounter === (numberOfEndpoints - 1)) {
      muteCounter = 0;
    }
    muteCounter++;
    let output = muteCounter + '/' + (numberOfEndpoints - 1) + ' other devices muted.';
    xapi.command('UserInterface Extensions Widget SetValue', {
      Value: output,
      WidgetId: muteStatusWidgetId
    });
  }
}

xapi.event.on('Message Send Text', event => {
  event = event.replace(/'/g,'"');
  try {
    var request = parse(event);
    //console.log(request);
    for (let [key, value] of Object.entries(request)) {
      if (key === 'xconfig') {
        console.log('Config change requested');
        remoteIP = value.Source;
        setConfig(value.Config, value.Value);
      } else if (key === 'xcommand') {
        //Example of syntax to issue a command
        xapi.command(value.Command, value.Value);
      } else if (key === 'response') {
        remoteIP = value.Source;
        console.log(value.Config + ' set to ' + value.Value + ' on ' + value.Source);
        statusText(value.Source, value.Value);
      }   
    }
  } catch(e) {
    console.log(e);
  }
});

//Input
//-----------------------------

//Check for 'mute others' request
xapi.event.on('UserInterface Extensions Widget Action', (event) => {
  if (event.WidgetId === muteOthersWidgetId && event.Type === 'clicked') {
    sendEvent(JSON.stringify({'xconfig': {'Config' : 'Audio Ultrasound MaxVolume', 'Value' : 0, 'Source' : myIP}}), 'allOthers');
    xapi.config.set('Audio Ultrasound MaxVolume', myDefaultUVolume);
    storedUltrasoundVolume = myDefaultUVolume;
    xapi.command('UserInterface Extensions Widget SetValue', {'Value': 'on', 'WidgetId': switchWidgetId});
    updateSlider(storedUltrasoundVolume, myDefaultUVolume);
  } else if (event.WidgetId === volumeWidgetId && event.Type === 'released') {
    newVolume = Math.ceil(event.Value * myDefaultUVolume / 255);
    xapi.config.set('Audio Ultrasound MaxVolume', newVolume);
    if (newVolume > 0) {
      updateMessage('The system proximity volume is ' + newVolume);
      xapi.command('UserInterface Extensions Widget SetValue', {'Value': 'on', 'WidgetId': switchWidgetId});
    } else {
      updateMessage('The system is muted');
      xapi.command('UserInterface Extensions Widget SetValue', {'Value': 'off', 'WidgetId': switchWidgetId});
    }
    storedUltrasoundVolume = newVolume;
  } else if (event.WidgetId === switchWidgetId) {
    if (event.Value === 'off') {
      xapi.config.set('Audio Ultrasound MaxVolume', 0);
      updateMessage('The system is muted');
      updateSlider(0, 1);
    } else if (event.Value === 'on') {
      xapi.config.set('Audio Ultrasound MaxVolume', storedUltrasoundVolume);
      updateMessage('The system proximity volume is ' + storedUltrasoundVolume);
      updateSlider(storedUltrasoundVolume, myDefaultUVolume);
    }
  }
});

//Set the In-Room control widgets appropriately
function setWidget(widgetId, widgetValue) {
  switch (widgetId) {
    case volumeWidgetId:
      if (myDefaultUVolume < widgetValue) {
        widgetValue = myDefaultUVolume;
      }
      let sliderLevel = Math.ceil(255 / myDefaultUVolume * widgetValue);
      xapi.command('UserInterface Extensions Widget SetValue', {'Value': sliderLevel, 'WidgetId': widgetId});
      break;
    case switchWidgetId:
      if (widgetValue > 0) {
        xapi.command('UserInterface Extensions Widget SetValue', {'Value': 'on', 'WidgetId': widgetId});
      } else {
        xapi.command('UserInterface Extensions Widget SetValue', {'Value': 'off', 'WidgetId': widgetId});
      }
      break;
    default:
      break;
  }
}

//Set the panel widget to the current config
function setFromConfig() {
  xapi.config.get('Audio Ultrasound MaxVolume').then((configUltrasoundVolume) => {
    storedUltrasoundVolume = configUltrasoundVolume;
    setWidget(volumeWidgetId, configUltrasoundVolume);
    setWidget(switchWidgetId, configUltrasoundVolume);
  });
}

//If the In-Room control panels get updated, set the panel widget correctly
xapi.event.on('UserInterface Extensions Widget LayoutUpdated', setFromConfig);

//Set the panel correctly
setFromConfig();